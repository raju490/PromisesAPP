"use strict"

angular
	.module("myApp")
	.config(function($stateProvider,$urlRouterProvider){
		$urlRouterProvider.otherwise("/");
		$stateProvider
			.state('Home',{
				url:'/',
				template:"<h1>Home Page</h1>"
			})
			.state('create',{
				url:'/create',
				controller:'createController',
				templateUrl:'contact.input.client.tpl.html'
			})
			.state('display',{
				url:'/display',
				controller:"displayController",
				templateUrl:'display.table.client.html'
			})
			.state('update',{
				url:"/update",
				controller:'updateController',
				templateUrl:'contact.input.client.tpl.html'
			})
			.state('delete',{
				url:'/delete',
				controller:"deleteController",
				templateUrl:"contact.input.client.tpl.html"
		});
	});