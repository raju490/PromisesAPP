angular
	.module("myApp")
	.controller("displayController",function($scope,contactServices,ngProgressFactory){
		$scope.progressbar = ngProgressFactory.createInstance();
		$scope.progressbar.start();
		if(contactServices.isThereContacts()) {
			var _contactsIt = {};
			//_contactsIt.contacts = contactServices.getContacts();
			var promise = contactServices.getContacts();
			console.log(promise.$state)

			promise.then(function(result){
				//console.log(result)
				_contactsIt.contacts = result;
				_contactsIt.headers = angular.copy(Object.keys(_contactsIt.contacts[0]));
				$scope.contacts = angular.copy(_contactsIt);
				//$scope.progressbar.complete();
			})
				.catch(function(error){
					$scope.data = error;
					//$scope.progressbar.complete();
				})
			//_contactsIt.headers = angular.copy(Object.keys(_contactsIt.contacts[0]));
			//$scope.contacts = angular.copy(_contactsIt);
			//$scope.data = "Hello";
			//console.log($scope.contacts.headers)
			console.log("waiting for data to come")
		}
		else{
			$scope.data = "No contact list"
			//$scope.progressbar.complete();
		}
		$scope.progressbar.complete();
	})
	.controller("createController",function($scope,contactServices,$timeout){
		$scope.heading = "Enter Contact Information";
		$scope.myValue = true;
		$scope.myUpdateButton = false;
		$scope.mySubmitButton = true;
		$scope.data = '';
		//console.log($scope.myForm.myInput.$valid)
		
		$scope.submit = function(person){
			
            //console.log("called within Create controller");
            //console.log(person);

			contactServices.newContact(person);
			$scope.person = {};
			$scope.data = "Created Successfully...!!!";
			$timeout(function(){$scope.data = ""},3000);

        }
	})
	.controller('updateController', function($scope,$window,$timeout,contactServices){
		$scope.heading = "Enter the contact name to be Updated";
		$scope.mySubmitButton = true;
        $scope.submit = function(person){
            //console.log("called within Update controller");
            //console.log(person);
			if(person!=undefined && contactServices.searchContact(person)) {
				$scope.myValue = true;
				$scope.mySubmitButton = false;
				$scope.myUpdateButton = true;
				$scope.disable = true;
			}
			else{
				$window.alert("User Not Found")
				$scope.person={};
			}

        }
		$scope.update = function(person){
			contactServices.updateContact(person);
			$scope.person = {};
			$scope.data = "Updated Successfully...!!!";
			$timeout(function(){$scope.data = ""},3000);
		}

    })
	.controller('deleteController',function($scope,$window,$timeout,contactServices){
		$scope.heading = "Enter the contact name to be Deleted";
		$scope.mySubmitButton = true;
		$scope.submit = function(person){
			if(person!= undefined && contactServices.searchContact(person)) {
				$scope.myValue = false;
				$scope.mySubmitButton = false;
				$scope.myUpdateButton = false;
				if(contactServices.deleteContact(person)){
					$scope.data = "Contact is Deleted...!!!";
					$timeout(function(){$scope.data = " "},3000);
				}

			}
			else{
				$window.alert("check the Username you entered");
			}
			$scope.person={};
		}
	})
	.factory("contactServices",function($q,$timeout){
		var contacts = [];
		var _isThereContacts = function(){
			if(contacts.length>0){
				return true;
			}
			else {
				return false;
			}

		}
		var _getContacts = function(){
			var deferred = $q.defer();
			$timeout(function(){
				//console.log(contacts)
				var x = Math.floor((Math.random() * 2) + 1);
				console.log(x)
				if(x==1){
					deferred.resolve(contacts)
				}
				deferred.reject("Error: No Result Found")
			},4000,contacts);

			return deferred.promise;
			//return contacts;
		}
		var _newContact = function(newContact){
			contacts.push(newContact);
		}
		var _updateContact = function(updContact){
			for (var i=0 ;i<=contacts.length;i++){
				if (contacts[i].username== updContact.username) {
					contacts[i].username = updContact.username
					contacts[i].age = updContact.age;
					contacts[i].occupation = updContact.occupation;
					contacts[i].email = updContact.email

					break;
				}
			}

		}

		var _searchContact = function(person) {
			if (person != undefined && contacts.length!=0) {
				for (var i = 0; i < contacts.length; i++) {
					if (contacts[i].username == person["username"]) {
						return true;
					}
				}
			}
			return false;
		}

		var _deleteContact = function(person) {
			if (person != undefined && contacts.length!=0) {
				for (var i = 0; i < contacts.length; i++) {
					if (contacts[i].username == person["username"]) {
						contacts.splice(i,1);
						//console.log(contacts);
						return true;
					}
				}
			}
			return false;
		}



		return{
			getContacts : _getContacts,
			newContact : _newContact,
			updateContact :_updateContact,
			searchContact:_searchContact,
			isThereContacts:_isThereContacts,
			deleteContact : _deleteContact
		}
	});